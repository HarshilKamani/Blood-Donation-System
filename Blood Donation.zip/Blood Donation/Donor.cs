﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Blood_Donation
{
    public partial class Donor : Form
    {
        public Donor()
        {
            InitializeComponent();
        }
        OleDbConnection con = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\a\OneDrive\Documents\Blood Donation\Blood Donation.accdb");

        private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        private void Reset()
        {
            DNameTb.Text = "";
            DAgeTb.Text = "";
            DPhoneTb.Text = "";
            DAddressTb.Text = "";
            DGenCb.Text = "";
            DBGroupCb.Text = "";
        }

        private void Savebtn_Click(object sender, EventArgs e)
        {
            if (DNameTb.Text == "" || DAgeTb.Text == "" || DPhoneTb.Text == "" || DAddressTb.Text == "")
            {
                MessageBox.Show("Missing information");

            }
            else
            {
                try
                {
                    string query = "Insert INTO DonorTable (DonorName,DonorAge,DonorGender,DonorPhoneNo,DonorAddress,DonorBloodGroup) values('" + DNameTb.Text + "','" + DAgeTb.Text + "','" + DGenCb.SelectedItem.ToString() + "','" + DPhoneTb.Text + "','" + DAddressTb.Text + "','" + DBGroupCb.SelectedItem.ToString() + "')";
                    con.Open();
                    OleDbCommand cmd = new OleDbCommand(query, con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Donor Saved SuccessFully");
                    con.Close();
                    Reset();

                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Donor_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'blood_DonationDataSet.DonorTable' table. You can move, or remove it, as needed.
            //this.donorTableTableAdapter.Fill(this.blood_DonationDataSet.DonorTable);

        }

        private void label17_Click(object sender, EventArgs e)
        {
            DonateBloods db = new DonateBloods();
            db.Show();
            this.Hide();
        }

        private void label3_Click(object sender, EventArgs e)
        {
            ViewDonor VD = new ViewDonor();
            VD.Show();
            this.Hide();
        }

        private void label4_Click(object sender, EventArgs e)
        {
            Patient Pa = new Patient();
            Pa.Show();
            this.Hide();
        }

        private void label5_Click(object sender, EventArgs e)
        {
            viewPatients VP = new viewPatients();
            VP.Show();
            this.Hide();
        }

        private void label6_Click(object sender, EventArgs e)
        {
            Blood_stock bs = new Blood_stock();
            bs.Show();
            this.Hide();
        }

        private void label8_Click(object sender, EventArgs e)
        {
            Blood_Transfer bt = new Blood_Transfer();
            bt.Show();
            this.Hide();
        }

        private void label7_Click(object sender, EventArgs e)
        {
            Dashboard das = new Dashboard();
            das.Show();
            this.Hide();
        }

        private void label9_Click(object sender, EventArgs e)
        {
            Login log = new Login();
            log.Show();
            this.Hide();
        }
    }
}
