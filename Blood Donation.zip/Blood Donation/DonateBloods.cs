﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Blood_Donation
{
    public partial class DonateBloods : Form
    {
        public DonateBloods()
        {
            InitializeComponent();
            populate();
            BloodStock();
        }
        OleDbConnection con = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\a\OneDrive\Documents\Blood Donation\Blood Donation.accdb");
        private void populate()
        {
            con.Open();
            string query = "select * from DonorTable";
            OleDbDataAdapter sda = new OleDbDataAdapter(query, con);
            OleDbCommandBuilder builder = new OleDbCommandBuilder(sda);
            var ds = new DataSet();
            sda.Fill(ds);
            DonateBloodDGV.DataSource = ds.Tables[0];
            con.Close();
        }
        private void reset()
        {
            NameTb.Text = "";
            BloodGroupTb.Text = "";
        }
        private void BloodStock()
        {
            con.Open();
            string query = "select * from BloodTable";
            OleDbDataAdapter sda = new OleDbDataAdapter(query, con);
            OleDbCommandBuilder builder = new OleDbCommandBuilder(sda);
            var ds = new DataSet();
            sda.Fill(ds);
            BloodStockDGV.DataSource = ds.Tables[0];
            con.Close();
        }
        int oldstock;
        private void GetStock(string Bgroup)
        {
            con.Open();
            string query = "select * from BloodTable where BGroup='" + Bgroup + "'";
            OleDbCommand cmd = new OleDbCommand(query, con);
            DataTable dt = new DataTable();
            OleDbDataAdapter sda = new OleDbDataAdapter(cmd);
            sda.Fill(dt);
            foreach (DataRow dr in dt.Rows)
            {
                oldstock = Convert.ToInt32(dr["BStock"].ToString());
            }
            con.Close();
        }
        private void Savebtn_Click(object sender, EventArgs e)
        {
            if (NameTb.Text == "")
            {
                MessageBox.Show("Select a Donor");

            }
            else
            {
                try
                {
                    int stock = oldstock + 1;
                    string query = "update BloodTable set BStock=" + stock + " where BGroup='" + BloodGroupTb.Text + "';";
                    con.Open();
                    OleDbCommand cmd = new OleDbCommand(query, con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Donation Successfull");
                    con.Close();
                    reset();
                    populate();
                    BloodStock();
                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void DonateBloodDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            NameTb.Text = DonateBloodDGV.SelectedRows[0].Cells[1].Value.ToString();
            BloodGroupTb.Text = DonateBloodDGV.SelectedRows[0].Cells[6].Value.ToString();
            GetStock(BloodGroupTb.Text);
        }

        private void label2_Click(object sender, EventArgs e)
        {
            Donor donor = new Donor();
            donor.Show();
            this.Hide();
        }

        private void label3_Click(object sender, EventArgs e)
        {
            ViewDonor VD = new ViewDonor();
            VD.Show();
            this.Hide();
        }

        private void label4_Click(object sender, EventArgs e)
        {
            Patient Pa = new Patient();
            Pa.Show();
            this.Hide();
        }

        private void label5_Click(object sender, EventArgs e)
        {
            viewPatients VP = new viewPatients();
            VP.Show();
            this.Hide();
        }

        private void label6_Click(object sender, EventArgs e)
        {
            Blood_stock bs = new Blood_stock();
            bs.Show();
            this.Hide();
        }

        private void label8_Click(object sender, EventArgs e)
        {
            Blood_Transfer bt = new Blood_Transfer();
            bt.Show();
            this.Hide();
        }

        private void label7_Click(object sender, EventArgs e)
        {
            Dashboard das = new Dashboard();
            das.Show();
            this.Hide();
        }

        private void label9_Click(object sender, EventArgs e)
        {
            Login log = new Login();
            log.Show();
            this.Hide();
        }
    }
}
