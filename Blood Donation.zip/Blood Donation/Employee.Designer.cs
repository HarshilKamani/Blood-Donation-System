﻿namespace Blood_Donation
{
    partial class Employee
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Employee));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle19 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle20 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle21 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle22 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle23 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle24 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle25 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle26 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle27 = new System.Windows.Forms.DataGridViewCellStyle();
            this.label11 = new System.Windows.Forms.Label();
            this.BloodGroupTb = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.NameTb = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.Donatebtn = new Bunifu.Framework.UI.BunifuThinButton2();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.label13 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.BloodStockDGV = new System.Windows.Forms.DataGridView();
            this.label14 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label10 = new System.Windows.Forms.Label();
            this.DonateBloodDGV = new System.Windows.Forms.DataGridView();
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.EmpPassTb = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.EmpNameTb = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.SaveBtn = new Bunifu.Framework.UI.BunifuThinButton2();
            this.Editbtn = new Bunifu.Framework.UI.BunifuThinButton2();
            this.DeleteBtn = new Bunifu.Framework.UI.BunifuThinButton2();
            this.EmployeeDGV = new System.Windows.Forms.DataGridView();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.BloodStockDGV)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DonateBloodDGV)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.EmployeeDGV)).BeginInit();
            this.SuspendLayout();
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Century Gothic", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Crimson;
            this.label11.Location = new System.Drawing.Point(481, 681);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(115, 40);
            this.label11.TabIndex = 136;
            this.label11.Text = "Name";
            // 
            // BloodGroupTb
            // 
            this.BloodGroupTb.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.BloodGroupTb.Enabled = false;
            this.BloodGroupTb.Font = new System.Drawing.Font("Century Gothic", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BloodGroupTb.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.BloodGroupTb.HintForeColor = System.Drawing.Color.Empty;
            this.BloodGroupTb.HintText = "";
            this.BloodGroupTb.isPassword = false;
            this.BloodGroupTb.LineFocusedColor = System.Drawing.Color.Blue;
            this.BloodGroupTb.LineIdleColor = System.Drawing.Color.Gray;
            this.BloodGroupTb.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.BloodGroupTb.LineThickness = 5;
            this.BloodGroupTb.Location = new System.Drawing.Point(1088, 748);
            this.BloodGroupTb.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.BloodGroupTb.Name = "BloodGroupTb";
            this.BloodGroupTb.Size = new System.Drawing.Size(314, 52);
            this.BloodGroupTb.TabIndex = 140;
            this.BloodGroupTb.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // NameTb
            // 
            this.NameTb.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.NameTb.Enabled = false;
            this.NameTb.Font = new System.Drawing.Font("Century Gothic", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NameTb.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.NameTb.HintForeColor = System.Drawing.Color.Empty;
            this.NameTb.HintText = "";
            this.NameTb.isPassword = false;
            this.NameTb.LineFocusedColor = System.Drawing.Color.Blue;
            this.NameTb.LineIdleColor = System.Drawing.Color.Gray;
            this.NameTb.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.NameTb.LineThickness = 5;
            this.NameTb.Location = new System.Drawing.Point(488, 748);
            this.NameTb.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.NameTb.Name = "NameTb";
            this.NameTb.Size = new System.Drawing.Size(314, 52);
            this.NameTb.TabIndex = 139;
            this.NameTb.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // Donatebtn
            // 
            this.Donatebtn.ActiveBorderThickness = 1;
            this.Donatebtn.ActiveCornerRadius = 20;
            this.Donatebtn.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.Donatebtn.ActiveForecolor = System.Drawing.Color.White;
            this.Donatebtn.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.Donatebtn.BackColor = System.Drawing.Color.OrangeRed;
            this.Donatebtn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Donatebtn.BackgroundImage")));
            this.Donatebtn.ButtonText = "Donate";
            this.Donatebtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Donatebtn.Font = new System.Drawing.Font("Century Gothic", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Donatebtn.ForeColor = System.Drawing.Color.SeaGreen;
            this.Donatebtn.IdleBorderThickness = 1;
            this.Donatebtn.IdleCornerRadius = 20;
            this.Donatebtn.IdleFillColor = System.Drawing.Color.Crimson;
            this.Donatebtn.IdleForecolor = System.Drawing.Color.White;
            this.Donatebtn.IdleLineColor = System.Drawing.Color.Crimson;
            this.Donatebtn.Location = new System.Drawing.Point(932, 863);
            this.Donatebtn.Margin = new System.Windows.Forms.Padding(5);
            this.Donatebtn.Name = "Donatebtn";
            this.Donatebtn.Size = new System.Drawing.Size(227, 57);
            this.Donatebtn.TabIndex = 142;
            this.Donatebtn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.SystemColors.Menu;
            this.panel5.Controls.Add(this.panel6);
            this.panel5.Location = new System.Drawing.Point(35, 130);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(10, 35);
            this.panel5.TabIndex = 9;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.SystemColors.Menu;
            this.panel6.Location = new System.Drawing.Point(-67, -3);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(10, 35);
            this.panel6.TabIndex = 8;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Century Gothic", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.Crimson;
            this.label13.Location = new System.Drawing.Point(1081, 702);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(222, 40);
            this.label13.TabIndex = 141;
            this.label13.Text = "Blood Group";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Century Gothic", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Black;
            this.label9.Location = new System.Drawing.Point(118, 880);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(119, 40);
            this.label9.TabIndex = 15;
            this.label9.Text = "logout";
            this.label9.Click += new System.EventHandler(this.label9_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Century Gothic", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.Gold;
            this.label12.Location = new System.Drawing.Point(75, 124);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(188, 40);
            this.label12.TabIndex = 7;
            this.label12.Text = "Employees";
            // 
            // button2
            // 
            this.button2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button2.BackgroundImage")));
            this.button2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Location = new System.Drawing.Point(47, 867);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(50, 72);
            this.button2.TabIndex = 3;
            this.button2.UseVisualStyleBackColor = true;
            // 
            // BloodStockDGV
            // 
            this.BloodStockDGV.AllowUserToAddRows = false;
            this.BloodStockDGV.AllowUserToOrderColumns = true;
            this.BloodStockDGV.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.BloodStockDGV.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.BloodStockDGV.BackgroundColor = System.Drawing.Color.White;
            this.BloodStockDGV.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.BloodStockDGV.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle19.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle19.BackColor = System.Drawing.Color.DarkRed;
            dataGridViewCellStyle19.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle19.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle19.SelectionBackColor = System.Drawing.Color.DarkRed;
            dataGridViewCellStyle19.SelectionForeColor = System.Drawing.Color.Lavender;
            dataGridViewCellStyle19.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.BloodStockDGV.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle19;
            this.BloodStockDGV.ColumnHeadersHeight = 28;
            this.BloodStockDGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.BloodStockDGV.Cursor = System.Windows.Forms.Cursors.Default;
            dataGridViewCellStyle20.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle20.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle20.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle20.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle20.SelectionBackColor = System.Drawing.Color.IndianRed;
            dataGridViewCellStyle20.SelectionForeColor = System.Drawing.Color.AliceBlue;
            dataGridViewCellStyle20.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.BloodStockDGV.DefaultCellStyle = dataGridViewCellStyle20;
            this.BloodStockDGV.EnableHeadersVisualStyles = false;
            this.BloodStockDGV.GridColor = System.Drawing.Color.White;
            this.BloodStockDGV.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.BloodStockDGV.Location = new System.Drawing.Point(416, 148);
            this.BloodStockDGV.Name = "BloodStockDGV";
            this.BloodStockDGV.ReadOnly = true;
            dataGridViewCellStyle21.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle21.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle21.Font = new System.Drawing.Font("Century Gothic", 14.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle21.ForeColor = System.Drawing.SystemColors.Info;
            dataGridViewCellStyle21.SelectionBackColor = System.Drawing.Color.IndianRed;
            dataGridViewCellStyle21.SelectionForeColor = System.Drawing.Color.AliceBlue;
            dataGridViewCellStyle21.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.BloodStockDGV.RowHeadersDefaultCellStyle = dataGridViewCellStyle21;
            this.BloodStockDGV.RowHeadersWidth = 51;
            this.BloodStockDGV.RowTemplate.Height = 24;
            this.BloodStockDGV.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.BloodStockDGV.Size = new System.Drawing.Size(377, 494);
            this.BloodStockDGV.TabIndex = 145;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Century Gothic", 24F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.Crimson;
            this.label14.Location = new System.Drawing.Point(1517, 69);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(224, 49);
            this.label14.TabIndex = 144;
            this.label14.Text = "Donors List";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.OrangeRed;
            this.panel2.Controls.Add(this.label11);
            this.panel2.Controls.Add(this.panel5);
            this.panel2.Controls.Add(this.BloodGroupTb);
            this.panel2.Controls.Add(this.label9);
            this.panel2.Controls.Add(this.NameTb);
            this.panel2.Controls.Add(this.label12);
            this.panel2.Controls.Add(this.Donatebtn);
            this.panel2.Controls.Add(this.button2);
            this.panel2.Controls.Add(this.label13);
            this.panel2.Controls.Add(this.BloodStockDGV);
            this.panel2.Controls.Add(this.label14);
            this.panel2.Controls.Add(this.label10);
            this.panel2.Controls.Add(this.DonateBloodDGV);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel2.Location = new System.Drawing.Point(0, 107);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(329, 995);
            this.panel2.TabIndex = 135;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Century Gothic", 24F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Crimson;
            this.label10.Location = new System.Drawing.Point(646, 81);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(169, 49);
            this.label10.TabIndex = 137;
            this.label10.Text = "Donate";
            // 
            // DonateBloodDGV
            // 
            this.DonateBloodDGV.AllowUserToAddRows = false;
            this.DonateBloodDGV.AllowUserToOrderColumns = true;
            this.DonateBloodDGV.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DonateBloodDGV.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.DonateBloodDGV.BackgroundColor = System.Drawing.Color.White;
            this.DonateBloodDGV.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.DonateBloodDGV.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle22.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle22.BackColor = System.Drawing.Color.DarkRed;
            dataGridViewCellStyle22.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle22.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle22.SelectionBackColor = System.Drawing.Color.DarkRed;
            dataGridViewCellStyle22.SelectionForeColor = System.Drawing.Color.Lavender;
            dataGridViewCellStyle22.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DonateBloodDGV.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle22;
            this.DonateBloodDGV.ColumnHeadersHeight = 28;
            this.DonateBloodDGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.DonateBloodDGV.Cursor = System.Windows.Forms.Cursors.Default;
            dataGridViewCellStyle23.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle23.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle23.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle23.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle23.SelectionBackColor = System.Drawing.Color.IndianRed;
            dataGridViewCellStyle23.SelectionForeColor = System.Drawing.Color.AliceBlue;
            dataGridViewCellStyle23.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.DonateBloodDGV.DefaultCellStyle = dataGridViewCellStyle23;
            this.DonateBloodDGV.EnableHeadersVisualStyles = false;
            this.DonateBloodDGV.GridColor = System.Drawing.Color.White;
            this.DonateBloodDGV.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.DonateBloodDGV.Location = new System.Drawing.Point(1103, 169);
            this.DonateBloodDGV.Name = "DonateBloodDGV";
            this.DonateBloodDGV.ReadOnly = true;
            dataGridViewCellStyle24.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle24.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle24.Font = new System.Drawing.Font("Century Gothic", 14.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle24.ForeColor = System.Drawing.SystemColors.Info;
            dataGridViewCellStyle24.SelectionBackColor = System.Drawing.Color.IndianRed;
            dataGridViewCellStyle24.SelectionForeColor = System.Drawing.Color.AliceBlue;
            dataGridViewCellStyle24.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DonateBloodDGV.RowHeadersDefaultCellStyle = dataGridViewCellStyle24;
            this.DonateBloodDGV.RowHeadersWidth = 51;
            this.DonateBloodDGV.RowTemplate.Height = 24;
            this.DonateBloodDGV.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DonateBloodDGV.Size = new System.Drawing.Size(1096, 494);
            this.DonateBloodDGV.TabIndex = 143;
            // 
            // button1
            // 
            this.button1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button1.BackgroundImage")));
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Location = new System.Drawing.Point(1855, 12);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(81, 72);
            this.button1.TabIndex = 2;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Gold;
            this.label1.Location = new System.Drawing.Point(786, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(706, 74);
            this.label1.TabIndex = 0;
            this.label1.Text = "Blood Donation System";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.OrangeRed;
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1942, 107);
            this.panel1.TabIndex = 134;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(689, 14);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(91, 86);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Century Gothic", 24F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.Crimson;
            this.label15.Location = new System.Drawing.Point(1009, 137);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(233, 49);
            this.label15.TabIndex = 146;
            this.label15.Text = "Employees";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Century Gothic", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.Crimson;
            this.label16.Location = new System.Drawing.Point(1325, 820);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(169, 40);
            this.label16.TabIndex = 150;
            this.label16.Text = "Password";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Century Gothic", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.Crimson;
            this.label17.Location = new System.Drawing.Point(837, 822);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(115, 40);
            this.label17.TabIndex = 147;
            this.label17.Text = "Name";
            // 
            // EmpPassTb
            // 
            this.EmpPassTb.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.EmpPassTb.Font = new System.Drawing.Font("Century Gothic", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EmpPassTb.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.EmpPassTb.HintForeColor = System.Drawing.Color.Empty;
            this.EmpPassTb.HintText = "";
            this.EmpPassTb.isPassword = false;
            this.EmpPassTb.LineFocusedColor = System.Drawing.Color.Blue;
            this.EmpPassTb.LineIdleColor = System.Drawing.Color.Gray;
            this.EmpPassTb.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.EmpPassTb.LineThickness = 5;
            this.EmpPassTb.Location = new System.Drawing.Point(1332, 865);
            this.EmpPassTb.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.EmpPassTb.Name = "EmpPassTb";
            this.EmpPassTb.Size = new System.Drawing.Size(314, 52);
            this.EmpPassTb.TabIndex = 149;
            this.EmpPassTb.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // EmpNameTb
            // 
            this.EmpNameTb.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.EmpNameTb.Font = new System.Drawing.Font("Century Gothic", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EmpNameTb.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.EmpNameTb.HintForeColor = System.Drawing.Color.Empty;
            this.EmpNameTb.HintText = "";
            this.EmpNameTb.isPassword = false;
            this.EmpNameTb.LineFocusedColor = System.Drawing.Color.Blue;
            this.EmpNameTb.LineIdleColor = System.Drawing.Color.Gray;
            this.EmpNameTb.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.EmpNameTb.LineThickness = 5;
            this.EmpNameTb.Location = new System.Drawing.Point(844, 867);
            this.EmpNameTb.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.EmpNameTb.Name = "EmpNameTb";
            this.EmpNameTb.Size = new System.Drawing.Size(314, 52);
            this.EmpNameTb.TabIndex = 148;
            this.EmpNameTb.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // SaveBtn
            // 
            this.SaveBtn.ActiveBorderThickness = 1;
            this.SaveBtn.ActiveCornerRadius = 20;
            this.SaveBtn.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.SaveBtn.ActiveForecolor = System.Drawing.Color.White;
            this.SaveBtn.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.SaveBtn.BackColor = System.Drawing.Color.White;
            this.SaveBtn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("SaveBtn.BackgroundImage")));
            this.SaveBtn.ButtonText = "Save";
            this.SaveBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.SaveBtn.Font = new System.Drawing.Font("Century Gothic", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SaveBtn.ForeColor = System.Drawing.Color.SeaGreen;
            this.SaveBtn.IdleBorderThickness = 1;
            this.SaveBtn.IdleCornerRadius = 20;
            this.SaveBtn.IdleFillColor = System.Drawing.Color.Crimson;
            this.SaveBtn.IdleForecolor = System.Drawing.Color.White;
            this.SaveBtn.IdleLineColor = System.Drawing.Color.Crimson;
            this.SaveBtn.Location = new System.Drawing.Point(876, 958);
            this.SaveBtn.Margin = new System.Windows.Forms.Padding(5);
            this.SaveBtn.Name = "SaveBtn";
            this.SaveBtn.Size = new System.Drawing.Size(227, 57);
            this.SaveBtn.TabIndex = 151;
            this.SaveBtn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.SaveBtn.Click += new System.EventHandler(this.SaveBtn_Click);
            // 
            // Editbtn
            // 
            this.Editbtn.ActiveBorderThickness = 1;
            this.Editbtn.ActiveCornerRadius = 20;
            this.Editbtn.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.Editbtn.ActiveForecolor = System.Drawing.Color.White;
            this.Editbtn.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.Editbtn.BackColor = System.Drawing.Color.White;
            this.Editbtn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Editbtn.BackgroundImage")));
            this.Editbtn.ButtonText = "Edit";
            this.Editbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Editbtn.Font = new System.Drawing.Font("Century Gothic", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Editbtn.ForeColor = System.Drawing.Color.SeaGreen;
            this.Editbtn.IdleBorderThickness = 1;
            this.Editbtn.IdleCornerRadius = 20;
            this.Editbtn.IdleFillColor = System.Drawing.Color.SeaGreen;
            this.Editbtn.IdleForecolor = System.Drawing.Color.White;
            this.Editbtn.IdleLineColor = System.Drawing.Color.Crimson;
            this.Editbtn.Location = new System.Drawing.Point(1135, 962);
            this.Editbtn.Margin = new System.Windows.Forms.Padding(5);
            this.Editbtn.Name = "Editbtn";
            this.Editbtn.Size = new System.Drawing.Size(227, 53);
            this.Editbtn.TabIndex = 152;
            this.Editbtn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Editbtn.Click += new System.EventHandler(this.Editbtn_Click);
            // 
            // DeleteBtn
            // 
            this.DeleteBtn.ActiveBorderThickness = 1;
            this.DeleteBtn.ActiveCornerRadius = 20;
            this.DeleteBtn.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.DeleteBtn.ActiveForecolor = System.Drawing.Color.White;
            this.DeleteBtn.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.DeleteBtn.BackColor = System.Drawing.Color.White;
            this.DeleteBtn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("DeleteBtn.BackgroundImage")));
            this.DeleteBtn.ButtonText = "Delete";
            this.DeleteBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.DeleteBtn.Font = new System.Drawing.Font("Century Gothic", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DeleteBtn.ForeColor = System.Drawing.Color.SeaGreen;
            this.DeleteBtn.IdleBorderThickness = 1;
            this.DeleteBtn.IdleCornerRadius = 20;
            this.DeleteBtn.IdleFillColor = System.Drawing.Color.Red;
            this.DeleteBtn.IdleForecolor = System.Drawing.Color.White;
            this.DeleteBtn.IdleLineColor = System.Drawing.Color.Red;
            this.DeleteBtn.Location = new System.Drawing.Point(1386, 958);
            this.DeleteBtn.Margin = new System.Windows.Forms.Padding(5);
            this.DeleteBtn.Name = "DeleteBtn";
            this.DeleteBtn.Size = new System.Drawing.Size(227, 57);
            this.DeleteBtn.TabIndex = 153;
            this.DeleteBtn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.DeleteBtn.Click += new System.EventHandler(this.DeleteBtn_Click);
            // 
            // EmployeeDGV
            // 
            this.EmployeeDGV.AllowUserToAddRows = false;
            this.EmployeeDGV.AllowUserToOrderColumns = true;
            this.EmployeeDGV.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.EmployeeDGV.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.EmployeeDGV.BackgroundColor = System.Drawing.Color.White;
            this.EmployeeDGV.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.EmployeeDGV.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle25.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle25.BackColor = System.Drawing.Color.DarkRed;
            dataGridViewCellStyle25.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle25.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle25.SelectionBackColor = System.Drawing.Color.DarkRed;
            dataGridViewCellStyle25.SelectionForeColor = System.Drawing.Color.Lavender;
            dataGridViewCellStyle25.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.EmployeeDGV.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle25;
            this.EmployeeDGV.ColumnHeadersHeight = 28;
            this.EmployeeDGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.EmployeeDGV.Cursor = System.Windows.Forms.Cursors.Default;
            dataGridViewCellStyle26.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle26.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle26.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle26.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle26.SelectionBackColor = System.Drawing.Color.IndianRed;
            dataGridViewCellStyle26.SelectionForeColor = System.Drawing.Color.AliceBlue;
            dataGridViewCellStyle26.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.EmployeeDGV.DefaultCellStyle = dataGridViewCellStyle26;
            this.EmployeeDGV.EnableHeadersVisualStyles = false;
            this.EmployeeDGV.GridColor = System.Drawing.Color.White;
            this.EmployeeDGV.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.EmployeeDGV.Location = new System.Drawing.Point(604, 302);
            this.EmployeeDGV.Name = "EmployeeDGV";
            this.EmployeeDGV.ReadOnly = true;
            dataGridViewCellStyle27.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle27.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle27.Font = new System.Drawing.Font("Century Gothic", 14.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle27.ForeColor = System.Drawing.SystemColors.Info;
            dataGridViewCellStyle27.SelectionBackColor = System.Drawing.Color.IndianRed;
            dataGridViewCellStyle27.SelectionForeColor = System.Drawing.Color.AliceBlue;
            dataGridViewCellStyle27.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.EmployeeDGV.RowHeadersDefaultCellStyle = dataGridViewCellStyle27;
            this.EmployeeDGV.RowHeadersWidth = 51;
            this.EmployeeDGV.RowTemplate.Height = 24;
            this.EmployeeDGV.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.EmployeeDGV.Size = new System.Drawing.Size(1137, 494);
            this.EmployeeDGV.TabIndex = 154;
            this.EmployeeDGV.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.EmployeeDGV_CellContentClick);
            // 
            // Employee
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1942, 1102);
            this.Controls.Add(this.EmployeeDGV);
            this.Controls.Add(this.DeleteBtn);
            this.Controls.Add(this.Editbtn);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.EmpPassTb);
            this.Controls.Add(this.EmpNameTb);
            this.Controls.Add(this.SaveBtn);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label15);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Employee";
            this.Text = "Employee";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Employee_Load);
            this.panel5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.BloodStockDGV)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DonateBloodDGV)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.EmployeeDGV)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label11;
        private Bunifu.Framework.UI.BunifuMaterialTextbox BloodGroupTb;
        private Bunifu.Framework.UI.BunifuMaterialTextbox NameTb;
        private Bunifu.Framework.UI.BunifuThinButton2 Donatebtn;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button button2;
        internal System.Windows.Forms.DataGridView BloodStockDGV;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label10;
        internal System.Windows.Forms.DataGridView DonateBloodDGV;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private Bunifu.Framework.UI.BunifuMaterialTextbox EmpPassTb;
        private Bunifu.Framework.UI.BunifuMaterialTextbox EmpNameTb;
        private Bunifu.Framework.UI.BunifuThinButton2 SaveBtn;
        private Bunifu.Framework.UI.BunifuThinButton2 Editbtn;
        private Bunifu.Framework.UI.BunifuThinButton2 DeleteBtn;
        internal System.Windows.Forms.DataGridView EmployeeDGV;
    }
}