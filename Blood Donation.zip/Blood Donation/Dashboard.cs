﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Blood_Donation
{
    public partial class Dashboard : Form
    {
        public Dashboard()
        {
            InitializeComponent();
            GetData();
        }
        OleDbConnection con = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\a\OneDrive\Documents\Blood Donation\Blood Donation.accdb");
        private void GetData()
        {
            con.Open();
            OleDbDataAdapter sda = new OleDbDataAdapter("select count(*) from DonorTable",con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            DonorLbl.Text = dt.Rows[0][0].ToString();
            OleDbDataAdapter sda1 = new OleDbDataAdapter("select count(*) from TransferTable", con);
            DataTable dt1 = new DataTable();
            sda1.Fill(dt1);
            TransferLbl.Text = dt1.Rows[0][0].ToString();
            OleDbDataAdapter sda2 = new OleDbDataAdapter("select count(*) from EmployeeTable", con);
            DataTable dt2 = new DataTable();
            sda2.Fill(dt2);
            UserLbl.Text = dt2.Rows[0][0].ToString();
            OleDbDataAdapter sda3 = new OleDbDataAdapter("select count(*) from BloodTable", con);
            DataTable dt3 = new DataTable();
            sda3.Fill(dt3);
            int BStock = Convert.ToInt32(dt3.Rows[0][0].ToString());
            TotalLbl.Text = ""+BStock;

            OleDbDataAdapter sda4 = new OleDbDataAdapter("select BStock from BloodTable where BGroup='" + "O+" + "'", con);
            DataTable dt4 = new DataTable();
            sda4.Fill(dt4);
            OPlusNum.Text = dt4.Rows[0][0].ToString();
            double OPlusPercentage = (Convert.ToDouble(dt4.Rows[0][0].ToString()) / BStock) * 100;
            OPlusProgress.Value = Convert.ToInt32(OPlusPercentage);

            OleDbDataAdapter sda5 = new OleDbDataAdapter("select BStock from BloodTable where BGroup='" + "AB+" + "'", con);
            DataTable dt5 = new DataTable();
            sda5.Fill(dt5);
            ABPlusLbl.Text = dt5.Rows[0][0].ToString();
            double ABPlusPercentage = (Convert.ToDouble(dt5.Rows[0][0].ToString()) / BStock) * 100;
            ABPlusProgress.Value = Convert.ToInt32(ABPlusPercentage);

            OleDbDataAdapter sda6 = new OleDbDataAdapter("select BStock from BloodTable where BGroup='" + "O-" + "'", con);
            DataTable dt6 = new DataTable();
            sda6.Fill(dt6);
            OMinusLbl.Text = dt6.Rows[0][0].ToString();
            double OMinusPercentage = (Convert.ToDouble(dt6.Rows[0][0].ToString()) / BStock) * 100;
            OMinusProgress.Value = Convert.ToInt32(OMinusPercentage);

            OleDbDataAdapter sda7 = new OleDbDataAdapter("select BStock from BloodTable where BGroup='" + "AB-" + "'", con);
            DataTable dt7 = new DataTable();
            sda7.Fill(dt7);
            ABMinusLbl.Text = dt7.Rows[0][0].ToString();
            double ABMinusPercentage = (Convert.ToDouble(dt7.Rows[0][0].ToString()) / BStock) * 100;
            ABMinusProgress.Value = Convert.ToInt32(ABMinusPercentage);
            con.Close();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            Donor donor = new Donor();
            donor.Show();
            this.Hide();
        }

        private void label11_Click(object sender, EventArgs e)
        {
            DonateBloods db = new DonateBloods();
            db.Show();
            this.Hide();
        }

        private void label3_Click(object sender, EventArgs e)
        {
            ViewDonor VD = new ViewDonor();
            VD.Show();
            this.Hide();
        }

        private void label4_Click(object sender, EventArgs e)
        {
            Patient Pa = new Patient();
            Pa.Show();
            this.Hide();
        }

        private void label5_Click(object sender, EventArgs e)
        {
            viewPatients VP = new viewPatients();
            VP.Show();
            this.Hide();
        }

        private void label6_Click(object sender, EventArgs e)
        {
            Blood_stock bs = new Blood_stock();
            bs.Show();
            this.Hide();
        }

        private void label8_Click(object sender, EventArgs e)
        {
            Blood_Transfer bt = new Blood_Transfer();
            bt.Show();
            this.Hide();
        }

        private void label9_Click(object sender, EventArgs e)
        {
            Login log = new Login();
            log.Show();
            this.Hide();
        }
    }
}
