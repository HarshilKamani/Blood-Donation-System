﻿
namespace Blood_Donation
{
    partial class Dashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Dashboard));
            this.label10 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label11 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label12 = new System.Windows.Forms.Label();
            this.DonorLbl = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.label13 = new System.Windows.Forms.Label();
            this.TransferLbl = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.panel6 = new System.Windows.Forms.Panel();
            this.label15 = new System.Windows.Forms.Label();
            this.UserLbl = new System.Windows.Forms.Label();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.OPlusProgress = new Guna.UI.WinForms.GunaCircleProgressBar();
            this.OPlusNum = new System.Windows.Forms.Label();
            this.TotalLbl = new System.Windows.Forms.Label();
            this.ABPlusProgress = new Guna.UI.WinForms.GunaCircleProgressBar();
            this.ABPlusLbl = new System.Windows.Forms.Label();
            this.OMinusProgress = new Guna.UI.WinForms.GunaCircleProgressBar();
            this.OMinusLbl = new System.Windows.Forms.Label();
            this.ABMinusProgress = new Guna.UI.WinForms.GunaCircleProgressBar();
            this.ABMinusLbl = new System.Windows.Forms.Label();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.OPlusProgress.SuspendLayout();
            this.ABPlusProgress.SuspendLayout();
            this.OMinusProgress.SuspendLayout();
            this.ABMinusProgress.SuspendLayout();
            this.SuspendLayout();
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Century Gothic", 24F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Crimson;
            this.label10.Location = new System.Drawing.Point(1038, 140);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(238, 49);
            this.label10.TabIndex = 37;
            this.label10.Text = "Dashboard";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Gold;
            this.label3.Location = new System.Drawing.Point(52, 267);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(204, 40);
            this.label3.TabIndex = 7;
            this.label3.Text = "View Donor";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Gold;
            this.label2.Location = new System.Drawing.Point(52, 78);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(116, 40);
            this.label2.TabIndex = 3;
            this.label2.Text = "Donor";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.OrangeRed;
            this.panel2.Controls.Add(this.label11);
            this.panel2.Controls.Add(this.label9);
            this.panel2.Controls.Add(this.button2);
            this.panel2.Controls.Add(this.label8);
            this.panel2.Controls.Add(this.label7);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel2.Location = new System.Drawing.Point(0, 107);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(329, 941);
            this.panel2.TabIndex = 36;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Century Gothic", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Gold;
            this.label11.Location = new System.Drawing.Point(52, 168);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(138, 40);
            this.label11.TabIndex = 16;
            this.label11.Text = "Donate";
            this.label11.Click += new System.EventHandler(this.label11_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Century Gothic", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Black;
            this.label9.Location = new System.Drawing.Point(120, 841);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(119, 40);
            this.label9.TabIndex = 15;
            this.label9.Text = "logout";
            this.label9.Click += new System.EventHandler(this.label9_Click);
            // 
            // button2
            // 
            this.button2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button2.BackgroundImage")));
            this.button2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Location = new System.Drawing.Point(49, 826);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(50, 72);
            this.button2.TabIndex = 3;
            this.button2.UseVisualStyleBackColor = true;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Century Gothic", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Gold;
            this.label8.Location = new System.Drawing.Point(52, 655);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(238, 40);
            this.label8.TabIndex = 11;
            this.label8.Text = "Blood Transfer";
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Century Gothic", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Gold;
            this.label7.Location = new System.Drawing.Point(52, 753);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(199, 40);
            this.label7.TabIndex = 13;
            this.label7.Text = "Dashboard";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Century Gothic", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Gold;
            this.label6.Location = new System.Drawing.Point(52, 554);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(204, 40);
            this.label6.TabIndex = 11;
            this.label6.Text = "Blood Stock";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Century Gothic", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Gold;
            this.label5.Location = new System.Drawing.Point(52, 456);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(229, 40);
            this.label5.TabIndex = 11;
            this.label5.Text = "View Patients";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Gold;
            this.label4.Location = new System.Drawing.Point(52, 362);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(141, 40);
            this.label4.TabIndex = 9;
            this.label4.Text = "Patients";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.Menu;
            this.panel3.Location = new System.Drawing.Point(25, 755);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(10, 35);
            this.panel3.TabIndex = 6;
            // 
            // button1
            // 
            this.button1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button1.BackgroundImage")));
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Location = new System.Drawing.Point(1855, 12);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(81, 72);
            this.button1.TabIndex = 2;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(697, 12);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(91, 86);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Gold;
            this.label1.Location = new System.Drawing.Point(794, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(706, 74);
            this.label1.TabIndex = 0;
            this.label1.Text = "Blood Donation System";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.OrangeRed;
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1942, 107);
            this.panel1.TabIndex = 35;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.Indigo;
            this.panel4.Controls.Add(this.label12);
            this.panel4.Controls.Add(this.DonorLbl);
            this.panel4.Controls.Add(this.pictureBox1);
            this.panel4.Location = new System.Drawing.Point(571, 320);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(322, 143);
            this.panel4.TabIndex = 38;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.Gold;
            this.label12.Location = new System.Drawing.Point(52, 84);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(95, 30);
            this.label12.TabIndex = 16;
            this.label12.Text = "Donors";
            // 
            // DonorLbl
            // 
            this.DonorLbl.AutoSize = true;
            this.DonorLbl.Font = new System.Drawing.Font("Century Gothic", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DonorLbl.ForeColor = System.Drawing.Color.Gold;
            this.DonorLbl.Location = new System.Drawing.Point(49, 28);
            this.DonorLbl.Name = "DonorLbl";
            this.DonorLbl.Size = new System.Drawing.Size(132, 45);
            this.DonorLbl.TabIndex = 16;
            this.DonorLbl.Text = "Donor";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(217, 28);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(91, 86);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 3;
            this.pictureBox1.TabStop = false;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.Green;
            this.panel5.Controls.Add(this.label13);
            this.panel5.Controls.Add(this.TransferLbl);
            this.panel5.Controls.Add(this.pictureBox3);
            this.panel5.Location = new System.Drawing.Point(1091, 320);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(322, 143);
            this.panel5.TabIndex = 39;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.Gold;
            this.label13.Location = new System.Drawing.Point(52, 84);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(113, 30);
            this.label13.TabIndex = 16;
            this.label13.Text = "Transfers";
            // 
            // TransferLbl
            // 
            this.TransferLbl.AutoSize = true;
            this.TransferLbl.Font = new System.Drawing.Font("Century Gothic", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TransferLbl.ForeColor = System.Drawing.Color.Gold;
            this.TransferLbl.Location = new System.Drawing.Point(49, 28);
            this.TransferLbl.Name = "TransferLbl";
            this.TransferLbl.Size = new System.Drawing.Size(159, 45);
            this.TransferLbl.TabIndex = 16;
            this.TransferLbl.Text = "Transfer";
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(217, 28);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(91, 86);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 3;
            this.pictureBox3.TabStop = false;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.OrangeRed;
            this.panel6.Controls.Add(this.label15);
            this.panel6.Controls.Add(this.UserLbl);
            this.panel6.Controls.Add(this.pictureBox4);
            this.panel6.Location = new System.Drawing.Point(1608, 320);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(322, 143);
            this.panel6.TabIndex = 40;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.Gold;
            this.label15.Location = new System.Drawing.Point(47, 84);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(72, 30);
            this.label15.TabIndex = 16;
            this.label15.Text = "Users";
            // 
            // UserLbl
            // 
            this.UserLbl.AutoSize = true;
            this.UserLbl.Font = new System.Drawing.Font("Century Gothic", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UserLbl.ForeColor = System.Drawing.Color.Gold;
            this.UserLbl.Location = new System.Drawing.Point(44, 26);
            this.UserLbl.Name = "UserLbl";
            this.UserLbl.Size = new System.Drawing.Size(113, 45);
            this.UserLbl.TabIndex = 16;
            this.UserLbl.Text = "Users";
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(217, 28);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(91, 86);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 3;
            this.pictureBox4.TabStop = false;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Century Gothic", 24F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.Crimson;
            this.label17.Location = new System.Drawing.Point(1038, 561);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(250, 49);
            this.label17.TabIndex = 41;
            this.label17.Text = "Blood Stock";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.Crimson;
            this.label18.Location = new System.Drawing.Point(771, 708);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(61, 37);
            this.label18.TabIndex = 46;
            this.label18.Text = "O+";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.Color.Crimson;
            this.label19.Location = new System.Drawing.Point(995, 708);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(73, 37);
            this.label19.TabIndex = 47;
            this.label19.Text = "AB+";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.Color.Crimson;
            this.label20.Location = new System.Drawing.Point(1246, 708);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(53, 37);
            this.label20.TabIndex = 48;
            this.label20.Text = "O-";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.ForeColor = System.Drawing.Color.Crimson;
            this.label21.Location = new System.Drawing.Point(1485, 708);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(65, 37);
            this.label21.TabIndex = 49;
            this.label21.Text = "AB-";
            // 
            // OPlusProgress
            // 
            this.OPlusProgress.AnimationSpeed = 0.6F;
            this.OPlusProgress.BaseColor = System.Drawing.Color.White;
            this.OPlusProgress.Controls.Add(this.OPlusNum);
            this.OPlusProgress.IdleColor = System.Drawing.Color.Gainsboro;
            this.OPlusProgress.IdleOffset = 20;
            this.OPlusProgress.IdleThickness = 10;
            this.OPlusProgress.Image = null;
            this.OPlusProgress.ImageSize = new System.Drawing.Size(52, 52);
            this.OPlusProgress.Location = new System.Drawing.Point(718, 754);
            this.OPlusProgress.Name = "OPlusProgress";
            this.OPlusProgress.ProgressMaxColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.OPlusProgress.ProgressMinColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.OPlusProgress.ProgressOffset = 20;
            this.OPlusProgress.ProgressThickness = 10;
            this.OPlusProgress.Size = new System.Drawing.Size(175, 162);
            this.OPlusProgress.TabIndex = 50;
            // 
            // OPlusNum
            // 
            this.OPlusNum.AutoSize = true;
            this.OPlusNum.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OPlusNum.ForeColor = System.Drawing.Color.Crimson;
            this.OPlusNum.Location = new System.Drawing.Point(67, 59);
            this.OPlusNum.Name = "OPlusNum";
            this.OPlusNum.Size = new System.Drawing.Size(39, 37);
            this.OPlusNum.TabIndex = 54;
            this.OPlusNum.Text = "N";
            // 
            // TotalLbl
            // 
            this.TotalLbl.AutoSize = true;
            this.TotalLbl.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TotalLbl.ForeColor = System.Drawing.Color.Crimson;
            this.TotalLbl.Location = new System.Drawing.Point(1121, 630);
            this.TotalLbl.Name = "TotalLbl";
            this.TotalLbl.Size = new System.Drawing.Size(86, 37);
            this.TotalLbl.TabIndex = 54;
            this.TotalLbl.Text = "Total";
            // 
            // ABPlusProgress
            // 
            this.ABPlusProgress.AnimationSpeed = 0.6F;
            this.ABPlusProgress.BaseColor = System.Drawing.Color.White;
            this.ABPlusProgress.Controls.Add(this.ABPlusLbl);
            this.ABPlusProgress.IdleColor = System.Drawing.Color.Gainsboro;
            this.ABPlusProgress.IdleOffset = 20;
            this.ABPlusProgress.IdleThickness = 10;
            this.ABPlusProgress.Image = null;
            this.ABPlusProgress.ImageSize = new System.Drawing.Size(52, 52);
            this.ABPlusProgress.Location = new System.Drawing.Point(941, 754);
            this.ABPlusProgress.Name = "ABPlusProgress";
            this.ABPlusProgress.ProgressMaxColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.ABPlusProgress.ProgressMinColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.ABPlusProgress.ProgressOffset = 20;
            this.ABPlusProgress.ProgressThickness = 10;
            this.ABPlusProgress.Size = new System.Drawing.Size(175, 162);
            this.ABPlusProgress.TabIndex = 55;
            // 
            // ABPlusLbl
            // 
            this.ABPlusLbl.AutoSize = true;
            this.ABPlusLbl.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ABPlusLbl.ForeColor = System.Drawing.Color.Crimson;
            this.ABPlusLbl.Location = new System.Drawing.Point(68, 59);
            this.ABPlusLbl.Name = "ABPlusLbl";
            this.ABPlusLbl.Size = new System.Drawing.Size(39, 37);
            this.ABPlusLbl.TabIndex = 55;
            this.ABPlusLbl.Text = "N";
            // 
            // OMinusProgress
            // 
            this.OMinusProgress.AnimationSpeed = 0.6F;
            this.OMinusProgress.BaseColor = System.Drawing.Color.White;
            this.OMinusProgress.Controls.Add(this.OMinusLbl);
            this.OMinusProgress.IdleColor = System.Drawing.Color.Gainsboro;
            this.OMinusProgress.IdleOffset = 20;
            this.OMinusProgress.IdleThickness = 10;
            this.OMinusProgress.Image = null;
            this.OMinusProgress.ImageSize = new System.Drawing.Size(52, 52);
            this.OMinusProgress.Location = new System.Drawing.Point(1181, 754);
            this.OMinusProgress.Name = "OMinusProgress";
            this.OMinusProgress.ProgressMaxColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.OMinusProgress.ProgressMinColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.OMinusProgress.ProgressOffset = 20;
            this.OMinusProgress.ProgressThickness = 10;
            this.OMinusProgress.Size = new System.Drawing.Size(175, 162);
            this.OMinusProgress.TabIndex = 56;
            // 
            // OMinusLbl
            // 
            this.OMinusLbl.AutoSize = true;
            this.OMinusLbl.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OMinusLbl.ForeColor = System.Drawing.Color.Crimson;
            this.OMinusLbl.Location = new System.Drawing.Point(68, 59);
            this.OMinusLbl.Name = "OMinusLbl";
            this.OMinusLbl.Size = new System.Drawing.Size(39, 37);
            this.OMinusLbl.TabIndex = 56;
            this.OMinusLbl.Text = "N";
            // 
            // ABMinusProgress
            // 
            this.ABMinusProgress.AnimationSpeed = 0.6F;
            this.ABMinusProgress.BaseColor = System.Drawing.Color.White;
            this.ABMinusProgress.Controls.Add(this.ABMinusLbl);
            this.ABMinusProgress.IdleColor = System.Drawing.Color.Gainsboro;
            this.ABMinusProgress.IdleOffset = 20;
            this.ABMinusProgress.IdleThickness = 10;
            this.ABMinusProgress.Image = null;
            this.ABMinusProgress.ImageSize = new System.Drawing.Size(52, 52);
            this.ABMinusProgress.Location = new System.Drawing.Point(1423, 754);
            this.ABMinusProgress.Name = "ABMinusProgress";
            this.ABMinusProgress.ProgressMaxColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.ABMinusProgress.ProgressMinColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.ABMinusProgress.ProgressOffset = 20;
            this.ABMinusProgress.ProgressThickness = 10;
            this.ABMinusProgress.Size = new System.Drawing.Size(175, 162);
            this.ABMinusProgress.TabIndex = 57;
            // 
            // ABMinusLbl
            // 
            this.ABMinusLbl.AutoSize = true;
            this.ABMinusLbl.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ABMinusLbl.ForeColor = System.Drawing.Color.Crimson;
            this.ABMinusLbl.Location = new System.Drawing.Point(67, 59);
            this.ABMinusLbl.Name = "ABMinusLbl";
            this.ABMinusLbl.Size = new System.Drawing.Size(39, 37);
            this.ABMinusLbl.TabIndex = 57;
            this.ABMinusLbl.Text = "N";
            // 
            // Dashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1942, 1048);
            this.Controls.Add(this.ABMinusProgress);
            this.Controls.Add(this.OMinusProgress);
            this.Controls.Add(this.ABPlusProgress);
            this.Controls.Add(this.TotalLbl);
            this.Controls.Add(this.OPlusProgress);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Dashboard";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Dashboard";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.OPlusProgress.ResumeLayout(false);
            this.OPlusProgress.PerformLayout();
            this.ABPlusProgress.ResumeLayout(false);
            this.ABPlusProgress.PerformLayout();
            this.OMinusProgress.ResumeLayout(false);
            this.OMinusProgress.PerformLayout();
            this.ABMinusProgress.ResumeLayout(false);
            this.ABMinusProgress.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label DonorLbl;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label TransferLbl;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label UserLbl;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private Guna.UI.WinForms.GunaCircleProgressBar OPlusProgress;
        private System.Windows.Forms.Label OPlusNum;
        private System.Windows.Forms.Label TotalLbl;
        private Guna.UI.WinForms.GunaCircleProgressBar ABPlusProgress;
        private Guna.UI.WinForms.GunaCircleProgressBar OMinusProgress;
        private Guna.UI.WinForms.GunaCircleProgressBar ABMinusProgress;
        private System.Windows.Forms.Label ABPlusLbl;
        private System.Windows.Forms.Label OMinusLbl;
        private System.Windows.Forms.Label ABMinusLbl;
        private System.Windows.Forms.Label label11;
    }
}