﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;


namespace Blood_Donation
{
    public partial class Blood_Transfer : Form
    {
        public Blood_Transfer()
        {
            InitializeComponent();
            FillPatientCb();
        }
        OleDbConnection con = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\a\OneDrive\Documents\Blood Donation\Blood Donation.accdb");


        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        private void FillPatientCb()
        {
            con.Open();
            OleDbCommand cmd = new OleDbCommand("select PId from PatientTable", con);
            OleDbDataReader rdr;
            rdr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Columns.Add("PId", typeof(int));
            dt.Load(rdr);
            PatientIdCb.ValueMember = "PId";
            PatientIdCb.DataSource = dt;
            con.Close();
        }
        private void GetData()
        {
            con.Open();
            string query = "select * from PatientTable where PID=" + PatientIdCb.SelectedValue.ToString() + ";";
            OleDbCommand cmd = new OleDbCommand(query, con);
            DataTable dt = new DataTable();
            OleDbDataAdapter sda = new OleDbDataAdapter(cmd);
            sda.Fill(dt);
            foreach (DataRow dr in dt.Rows)
            {
                PatNameTb.Text = dr["PName"].ToString();
                BloodGroup.Text = dr["PBloodGroup"].ToString();
            }
            con.Close();
        }

        int stock;
        private void GetStock(string Bgroup)
        {
            con.Open();
            string query = "select * from BloodTable where BGroup='" + Bgroup + "'";
            OleDbCommand cmd = new OleDbCommand(query, con);
            DataTable dt = new DataTable();
            OleDbDataAdapter sda = new OleDbDataAdapter(cmd);
            sda.Fill(dt);
            foreach (DataRow dr in dt.Rows)
            {
                stock = Convert.ToInt32(dr["BStock"].ToString());
            }
            con.Close();
        }
        private void Reset()
        {
            PatNameTb.Text = "";
            BloodGroup.Text = "";
            AvailableLbl.Visible = false;
            Transferbtn.Visible = false;
        }
        private void updatestock()
        {
            int newstock = stock - 1;
            try
            {
                con.Open();
                string query = "update BloodTable set Bstock=" + newstock + " where BGroup='" + BloodGroup.Text + "';";
                OleDbCommand cmd = new OleDbCommand(query, con);
                cmd.ExecuteNonQuery();
                MessageBox.Show(" Successfully Transfer");
                con.Close();
                
                

            }
            catch (Exception Ex)
            {
                MessageBox.Show(Ex.Message);
            }
        }
        private void Transferbtn_Click(object sender, EventArgs e)
        {
            if (PatNameTb.Text == "")
            {
                MessageBox.Show("Missing information");

            }
            else
            {
                try
                {
                    string query = "Insert INTO TransferTable (PName,BGroup) values('" + PatNameTb.Text + "','" + BloodGroup.Text + "')";
                    con.Open();
                    OleDbCommand cmd = new OleDbCommand(query, con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("SuccessFully Transfer");
                    con.Close();
                    GetStock(BloodGroup.Text);                   
                    updatestock();
                    Reset();
                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
        }

        private void PatientIdCb_SelectionChangeCommitted(object sender, EventArgs e)
        {
            GetData();
            GetStock(BloodGroup.Text);
            if (stock > 0)
            {
                Transferbtn.Visible = true;
                AvailableLbl.Text = "Available Stock";
                AvailableLbl.Visible = true;
            }
            else
            {
                AvailableLbl.Text = " Stock not Available";
                AvailableLbl.Visible = true;
            }
        }

        private void label4_Click(object sender, EventArgs e)
        {
            Patient pat = new Patient();
            pat.Show();
            this.Hide();
        }

        private void label6_Click(object sender, EventArgs e)
        {
            Blood_stock Bstock = new Blood_stock();
            Bstock.Show();
            this.Hide();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            Donor donor = new Donor();
            donor.Show();
            this.Hide();
        }

        private void label13_Click(object sender, EventArgs e)
        {
            DonateBloods db = new DonateBloods();
            db.Show();
            this.Hide();
        }

        private void label3_Click(object sender, EventArgs e)
        {
            ViewDonor VD = new ViewDonor();
            VD.Show();
            this.Hide();
        }

        private void label5_Click(object sender, EventArgs e)
        {
            viewPatients VP = new viewPatients();
            VP.Show();
            this.Hide();
        }

        private void label8_Click(object sender, EventArgs e)
        {
            Blood_Transfer bt = new Blood_Transfer();
            bt.Show();
            this.Hide();
        }

        private void label7_Click(object sender, EventArgs e)
        {
            Dashboard das = new Dashboard();
            das.Show();
            this.Hide();
        }

        private void label9_Click(object sender, EventArgs e)
        {
            Login log = new Login();
            log.Show();
            this.Hide();
        }

    }
}


